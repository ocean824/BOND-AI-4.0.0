export const rateLimits = {
  aiExtractionPerMinute: 10,
  pricingPerMinute: 20,
  chatPerMinute: 30
};
