export const featureFlags = {
  dualAiExtraction: true,
  investorDashboard: true,
  aiOnboarder: true
};
