export type Role = 'admin' | 'analyst' | 'investor';

export const permissions: Record<Role, string[]> = {
  admin: ['judgments:read', 'judgments:write', 'bundles:read', 'bundles:write', 'users:manage'],
  analyst: ['judgments:read', 'judgments:write', 'bundles:read', 'bundles:write'],
  investor: ['bundles:read', 'judgments:read']
};
