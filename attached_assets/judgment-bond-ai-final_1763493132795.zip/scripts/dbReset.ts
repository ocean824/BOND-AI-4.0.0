import 'dotenv/config';
import { db } from '../server/db/client.js';
import { users, judgments, recoveryScores, priceEstimates, bundles, bundleJudgments, chatSessions, chatMessages } from '../db/schema.js';

async function main() {
  console.log('Resetting database data (truncating tables)...');
  // Order matters to satisfy FKs
  await db.delete(chatMessages);
  await db.delete(chatSessions);
  await db.delete(bundleJudgments);
  await db.delete(bundles);
  await db.delete(priceEstimates);
  await db.delete(recoveryScores);
  await db.delete(judgments);
  await db.delete(users);
  console.log('✅ DB reset complete');
  process.exit(0);
}

main().catch((err) => {
  console.error('❌ DB reset failed', err);
  process.exit(1);
});
