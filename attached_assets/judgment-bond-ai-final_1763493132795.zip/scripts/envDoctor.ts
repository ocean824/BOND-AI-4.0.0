import 'dotenv/config';
import { EnvSchema } from '../server/config/env.js';

const parsed = EnvSchema.safeParse(process.env);

if (!parsed.success) {
  console.error('❌ Environment validation failed');
  console.error(JSON.stringify(parsed.error.format(), null, 2));
  process.exit(1);
}

console.log('✅ Environment looks good');
process.exit(0);
