import 'dotenv/config';
import { db } from '../server/db/client.js';
import {
  users,
  judgments,
  bundles,
  bundleJudgments,
  priceEstimates
} from '../db/schema.js';
import bcrypt from 'bcryptjs';

async function main() {
  console.log('Seeding admin user, sample judgment, price estimate, and bundle...');

  const email = 'admin@bondai.app';
  const password = 'admin123';

  const passwordHash = await bcrypt.hash(password, 10);

  // Upsert-like behavior for admin user
  let ownerId: number;

  const existingAdmins = await db
    .select()
    .from(users)
    .where(users.email.eq(email as any) as any)
    .limit(1);

  if (existingAdmins.length > 0) {
    ownerId = existingAdmins[0].id;
    console.log(`Admin user already exists with id=${ownerId}`);
  } else {
    const [admin] = await db
      .insert(users)
      .values({
        email,
        passwordHash,
        role: 'admin'
      })
      .returning();
    ownerId = admin.id;
    console.log(`Created admin user ${email} with id=${ownerId}`);
  }

  // Seed a sample judgment
  const [judgment] = await db
    .insert(judgments)
    .values({
      ownerId,
      debtorName: 'Sample Debtor LLC',
      caseNumber: 'CV-2024-0001',
      court: 'Circuit Court of Sample County',
      jurisdiction: 'Sample State',
      judgmentAmount: 150000.0,
      judgmentDate: new Date('2024-01-15T00:00:00Z'),
      status: 'new',
      rawText: 'Sample judgment text for testing.'
    })
    .returning();

  console.log(`Seeded sample judgment id=${judgment.id}`);

  // Seed a simple price estimate for that judgment
  const expectedRecoveryPct = 60; // %
  const discountRate = 30; // %
  const expectedRecoveryAmount =
    Number(judgment.judgmentAmount) * (expectedRecoveryPct / 100);
  const recommendedPurchasePrice =
    expectedRecoveryAmount * (1 - discountRate / 100);

  const [price] = await db
    .insert(priceEstimates)
    .values({
      judgmentId: judgment.id,
      targetIRR: 15,
      discountRate,
      recommendedPurchasePrice,
      scenarioJson: {
        expectedRecoveryAmount,
        model: 'simple-linear',
        note:
          'Deterministic pricing seeded for demo. Replace with Monte Carlo or AI model in production.'
      }
    })
    .returning();

  console.log(`Seeded price estimate id=${price.id}`);

  // Seed a demo bundle containing the judgment
  const [bundle] = await db
    .insert(bundles)
    .values({
      ownerId,
      name: 'Seed Bundle A',
      description: 'Demo bundle seeded for teaser PDF export',
      status: 'draft',
      metricsJson: {
        totalFaceValue: Number(judgment.judgmentAmount),
        totalRecommendedPurchasePrice: Number(recommendedPurchasePrice),
        judgmentCount: 1
      }
    })
    .returning();

  await db.insert(bundleJudgments).values({
    bundleId: bundle.id,
    judgmentId: judgment.id,
    tranche: 'senior'
  });

  console.log(`Seeded bundle id=${bundle.id} containing judgment id=${judgment.id}`);

  console.log('✅ Seed completed');
  process.exit(0);
}

main().catch((err) => {
  console.error('❌ Seed failed', err);
  process.exit(1);
});
