import 'dotenv/config';
import { db } from '../server/db/client.js';
import { judgments } from '../db/schema.js';

async function main() {
  console.log('Running smoke test...');

  const [one] = await db.select().from(judgments).limit(1);
  console.log('DB connectivity OK; sample judgment:', one?.id ?? 'none');

  console.log(
    'NOTE: For full smoke, run the server (npm run dev) and hit /api/healthz and /api/judgments.'
  );

  console.log('✅ Smoke test finished');
  process.exit(0);
}

main().catch((err) => {
  console.error('❌ Smoke test failed', err);
  process.exit(1);
});
