# Operations Guide – Judgment Bond AI

## Dev Mode

```bash
npm install
npm run env:check
npm run db:migrate
npm run seed
npm run dev
```

## Production Mode

```bash
npm install
npm run env:check
npm run db:migrate
npm run build
npm run start
```

## Env Vars

See `.env.example`.

## Health & Readiness

- `GET /api/healthz` – liveness
- `GET /api/readyz` – DB + AI key checks

## Metrics

- `GET /metrics` – Prometheus-style process metrics

## Logging

- Structured via pino, requestId included in error responses and `X-Request-Id` header.

## Runbooks

- App won't start → check env: `npm run env:check`, DB, logs.
- Health failing → inspect `/api/readyz`.
- High latency → look at AI call volume and `/metrics`.
