# Feature PRD – Judgment Ingestion

## Problem

Underwriters receive court judgments as PDFs or scans that are hard to parse and retype, causing delays and data risk.

## Goals

- Quickly onboard new judgments.
- Use AI extraction but keep humans in control.
- Store raw text + structured data for re-use.

## UX

- "Judgments" → "Upload"
- Fields: Debtor, Case #, Court, Jurisdiction, Amount, Date.
- AI Extract button and confidence indicators.

## Data Model

- Uses `judgments` table (ownerId, debtorName, caseNumber, court, jurisdiction, etc.).

## API

- `POST /api/judgments/upload`
- `POST /api/judgments/{id}/extract`
- `GET /api/judgments`
- `GET /api/judgments/{id}`

## Errors

- 400 VALIDATION_ERROR
- 401 AUTH_ERROR
- 404 NOT_FOUND
- 502 EXTERNAL_SERVICE_ERROR

## Analytics

- `judgment.uploaded`
- `judgment.ai_extracted`
- `judgment.extraction_corrected`

## Acceptance Criteria

- Upload creates a judgment row.
- Extract populates fields and updates status to "extracted".
- Unauthorized access is blocked.
