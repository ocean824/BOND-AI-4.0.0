# Judgment Bond AI – Product Requirements (Master)

## Purpose & Vision

Judgment Bond AI transforms raw court judgments into investable bond-like assets by:
- Ingesting PDFs
- Extracting structured case & debtor data with AI
- Predicting recovery likelihood
- Computing fair purchase prices
- Bundling high-scoring judgments into tranches
- Generating investor-ready analytics and materials

It is not legal or investment advice; it is a decision-support and workflow tool.

## Personas

- Admin
- Analyst
- Investor

## Core Flows

1. Judgment ingestion
2. AI extraction
3. Recovery scoring & pricing
4. Bundle & tranche construction
5. Investor analytics & AI onboarder

See feature PRDs under `docs/PRD/FEATURES` for detailed specs.
