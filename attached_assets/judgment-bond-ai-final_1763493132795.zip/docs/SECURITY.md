# Security & Compliance – Judgment Bond AI

## Threat Model

Internet-facing app with AI and Postgres; handles sensitive judgment data.

## OWASP Coverage (Summary)

- Access control via JWT + ownership checks.
- Crypto: bcrypt password hashing, env-based secrets.
- Injection: Drizzle ORM for SQL.
- Logging: pino with redaction.
- See source for full details.

## AuthZ Matrix

See config/permissions.ts for roles and actions.

## Rate Limiting

Implemented via `server/middleware/rateLimit.ts` keyed per user/IP and feature (aiExtraction, pricing, chat).

## Secrets

All loaded from env vars; `.env` is ignored by git.

## Headers

Server sets:

- X-Frame-Options: DENY
- X-Content-Type-Options: nosniff
- Referrer-Policy: strict-origin-when-cross-origin
- Content-Security-Policy: restrictive default with ReDoc + AI endpoints allowed.

## TODO

- Deeper audit logging and anomaly detection.
- Optional device fingerprinting and 2FA for admin accounts.
