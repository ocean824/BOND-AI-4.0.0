# Architecture – Judgment Bond AI

## Overview

- Frontend: React + Vite (SPA) in `app/`
- Backend: Fastify + TypeScript in `server/`
- DB: PostgreSQL via Drizzle ORM in `db/`
- AI: OpenAI (and optional Claude) via `aiExtractionService`

## Layers

- Routes → Services → DB (Drizzle)
- Middleware handles auth, request context, rate limiting.
- Config via `server/config/env.ts` and `config/*`.

## Boundaries

- AI logic isolated in `aiExtractionService` and `assistantService`.
- Pricing logic isolated in `pricingService`.
- No direct SQL; all through Drizzle.

## Security & Observability

- JWT auth, role-based permissions.
- RequestId and structured error handler.
- Health/ready/metrics endpoints for monitoring.
