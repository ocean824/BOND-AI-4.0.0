# Deploying on Replit – Judgment Bond AI

1. Create a new Node.js Replit.
2. Upload all project files or connect this repo.
3. Add a `.env` file based on `.env.example`.
4. In the Replit shell, run:

```bash
npm install
npm run db:migrate
npm run seed
```

5. The `.replit` file is configured to run:

```bash
npm install && npm run dev
```

This starts:

- API on port 3000
- Vite dev server on port 5173 (proxied)

6. Access the app via the Replit webview:

- Frontend: `/`
- API docs: `/api/docs`
- Health: `/api/healthz`
