import { User, Judgment, Bundle } from './types';

const API_BASE = '/api';

export interface AuthResponse {
  token: string;
  user: User;
}

let authToken: string | null = null;

export function setAuthToken(token: string | null) {
  authToken = token;
}

function headers() {
  const h: Record<string, string> = {
    'Content-Type': 'application/json'
  };
  if (authToken) h['Authorization'] = `Bearer ${authToken}`;
  return h;
}

async function handle<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let body: any;
    try {
      body = await res.json();
    } catch {
      body = { message: res.statusText };
    }
    throw new Error(body.message || body.code || res.statusText);
  }
  return res.json();
}

export const api = {
  async register(email: string, password: string): Promise<AuthResponse> {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    return handle<AuthResponse>(res);
  },
  async login(email: string, password: string): Promise<AuthResponse> {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    return handle<AuthResponse>(res);
  },
  async me(): Promise<{ user: User }> {
    const res = await fetch(`${API_BASE}/auth/me`, { headers: headers() });
    return handle(res);
  },
  async listJudgments(): Promise<Judgment[]> {
    const res = await fetch(`${API_BASE}/judgments`, { headers: headers() });
    return handle(res);
  },
  async uploadJudgment(pdfBase64: string): Promise<Judgment> {
    const res = await fetch(`${API_BASE}/judgments/upload`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ pdfBase64 })
    });
    return handle(res);
  },
  async extractJudgment(id: number, rawText: string): Promise<Judgment> {
    const res = await fetch(`${API_BASE}/judgments/${id}/extract`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ rawText })
    });
    return handle(res);
  },
  async investorMetrics() {
    const res = await fetch(`${API_BASE}/investor-metrics`, { headers: headers() });
    return handle(res);
  },
  async chat(message: string, contextJudgmentId?: number) {
    const res = await fetch(`${API_BASE}/assistant/chat`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ message, contextJudgmentId })
    });
    return handle<{ reply: string }>(res);
  }
};
