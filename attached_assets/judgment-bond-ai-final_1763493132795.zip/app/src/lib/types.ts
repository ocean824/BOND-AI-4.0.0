export type Role = 'admin' | 'analyst' | 'investor';

export interface User {
  id: number;
  email: string;
  role: Role;
}

export interface Judgment {
  id: number;
  debtorName: string;
  caseNumber: string;
  court: string;
  jurisdiction: string;
  judgmentAmount: number;
  judgmentDate: string;
  status: string;
}

export interface Bundle {
  id: number;
  name: string;
  description?: string;
  status: string;
}
