import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth';

export const NavBar: React.FC = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const onLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="navbar">
      <div className="navbar-brand">Judgment Bond AI</div>
      <nav className="nav-links">
        {user && (
          <>
            <Link to="/dashboard" className={location.pathname === '/dashboard' ? 'active' : ''}>
              Dashboard
            </Link>
            <Link to="/judgments" className={location.pathname === '/judgments' ? 'active' : ''}>
              Judgments
            </Link>
            <Link to="/bundles" className={location.pathname === '/bundles' ? 'active' : ''}>
              Bundles
            </Link>
            <Link
              to="/investor-dashboard"
              className={location.pathname === '/investor-dashboard' ? 'active' : ''}
            >
              Investor
            </Link>
          </>
        )}
        {!user && (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
          </>
        )}
        {user && (
          <button onClick={onLogout} style={{ marginLeft: '1rem' }}>
            Logout
          </button>
        )}
      </nav>
    </header>
  );
};
