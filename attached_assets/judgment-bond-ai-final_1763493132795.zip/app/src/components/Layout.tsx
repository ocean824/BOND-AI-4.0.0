import React from 'react';
import { NavBar } from './NavBar';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="layout">
      <NavBar />
      <main className="main">{children}</main>
    </div>
  );
};
