import React, { useState } from 'react';
import { api } from '../lib/apiClient';
import { useToast } from './ToastProvider';

export const AIOnboarderChat: React.FC = () => {
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<{ role: 'user' | 'assistant'; content: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const { showError } = useToast();

  const send = async () => {
    if (!input.trim()) return;
    const q = input.trim();
    setHistory((h) => [...h, { role: 'user', content: q }]);
    setInput('');
    setLoading(true);
    try {
      const res = await api.chat(q);
      setHistory((h) => [...h, { role: 'assistant', content: res.reply }]);
    } catch (e: any) {
      showError(e.message || 'Chat failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card" style={{ maxWidth: 360 }}>
      <h3>AI Pricing Assistant</h3>
      <p style={{ fontSize: '0.85rem', opacity: 0.8 }}>
        Ask things like &ldquo;How should I price a \$150k judgment?&rdquo;
      </p>
      <div
        style={{
          maxHeight: 260,
          overflowY: 'auto',
          marginBottom: '0.5rem',
          border: '1px solid #1f2937',
          borderRadius: 8,
          padding: 8
        }}
      >
        {history.length === 0 && (
          <p style={{ fontSize: '0.8rem', opacity: 0.7 }}>
            No messages yet. Start with: <em>How do you calculate recovery %?</em>
          </p>
        )}
        {history.map((m, i) => (
          <div
            key={i}
            style={{
              marginBottom: 4,
              textAlign: m.role === 'user' ? 'right' : 'left',
              fontSize: '0.85rem'
            }}
          >
            <strong>{m.role === 'user' ? 'You' : 'AI'}</strong>: {m.content}
          </div>
        ))}
      </div>
      <textarea
        rows={3}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Ask a pricing question..."
      />
      <button onClick={send} disabled={loading} style={{ marginTop: 8, width: '100%' }}>
        {loading ? 'Thinking...' : 'Ask AI'}
      </button>
    </div>
  );
};
