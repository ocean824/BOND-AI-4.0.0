import React, { useEffect, useState } from 'react';
import { api } from '../lib/apiClient';
import { Judgment } from '../lib/types';
import { useToast } from '../components/ToastProvider';

export const JudgmentsPage: React.FC = () => {
  const [judgments, setJudgments] = useState<Judgment[]>([]);
  const [uploadText, setUploadText] = useState('');
  const [extractText, setExtractText] = useState('');
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const { showError, showSuccess } = useToast();

  const load = async () => {
    try {
      const data = await api.listJudgments();
      setJudgments(data);
    } catch (e: any) {
      showError(e.message || 'Failed to load judgments');
    }
  };

  useEffect(() => {
    load();
  }, []);

  const onUpload = async () => {
    if (!uploadText.trim()) return;
    setLoading(true);
    try {
      // In real life, convert File → base64. Here we treat text length as stub.
      const base64 = btoa(uploadText);
      await api.uploadJudgment(base64);
      showSuccess('Uploaded judgment');
      setUploadText('');
      await load();
    } catch (e: any) {
      showError(e.message || 'Upload failed');
    } finally {
      setLoading(false);
    }
  };

  const onExtract = async () => {
    if (!selectedId || !extractText.trim()) return;
    setLoading(true);
    try {
      await api.extractJudgment(selectedId, extractText);
      showSuccess('AI extraction completed');
      setExtractText('');
      await load();
    } catch (e: any) {
      showError(e.message || 'Extraction failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-row">
      <div className="flex-1">
        <div className="card">
          <h2>Judgments</h2>
          <table className="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Debtor</th>
                <th>Case #</th>
                <th>Amount</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {judgments.map((j) => (
                <tr
                  key={j.id}
                  onClick={() => setSelectedId(j.id)}
                  style={{
                    cursor: 'pointer',
                    background: selectedId === j.id ? '#1e293b' : 'transparent'
                  }}
                >
                  <td>{j.id}</td>
                  <td>{j.debtorName}</td>
                  <td>{j.caseNumber}</td>
                  <td>${j.judgmentAmount}</td>
                  <td>{j.status}</td>
                </tr>
              ))}
              {judgments.length === 0 && (
                <tr>
                  <td colSpan={5} style={{ opacity: 0.7 }}>
                    No judgments yet. Upload one to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      <div style={{ width: 360 }}>
        <div className="card" style={{ marginBottom: 16 }}>
          <h3>Upload Judgment (Text Stub)</h3>
          <textarea
            rows={6}
            value={uploadText}
            onChange={(e) => setUploadText(e.target.value)}
            placeholder="Paste sample text to simulate a PDF..."
          />
          <button onClick={onUpload} disabled={loading} style={{ marginTop: 8, width: '100%' }}>
            {loading ? 'Working...' : 'Upload'}
          </button>
        </div>
        <div className="card">
          <h3>Run AI Extraction</h3>
          <p style={{ fontSize: '0.8rem', opacity: 0.75 }}>
            Select a judgment row, then paste raw text here to simulate extraction.
          </p>
          <textarea
            rows={6}
            value={extractText}
            onChange={(e) => setExtractText(e.target.value)}
            placeholder="Paste raw judgment text for AI extraction"
          />
          <button onClick={onExtract} disabled={loading || !selectedId} style={{ marginTop: 8, width: '100%' }}>
            {loading ? 'Extracting...' : 'Extract with AI'}
          </button>
        </div>
      </div>
    </div>
  );
};
