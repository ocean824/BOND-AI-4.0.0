import React from 'react';

export const BundlesPage: React.FC = () => {
  return (
    <div className="card">
      <h2>Bundles & Tranches</h2>
      <p>
        This is a placeholder for the tranche builder UI. In a future iteration, you will be
        able to select judgments, assign tranches (Senior / Mezz / Equity), and compute bundle
        metrics.
      </p>
    </div>
  );
};
