import React, { useEffect, useState } from 'react';
import { api } from '../lib/apiClient';
import { useToast } from '../components/ToastProvider';

interface Metrics {
  totalJudgments: number;
  totalFaceValue: number;
  totalRecommendedPrice: number;
  seniorShare: number;
  mezzShare: number;
  equityShare: number;
}

export const InvestorDashboardPage: React.FC = () => {
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const { showError } = useToast();

  useEffect(() => {
    (async () => {
      try {
        const m = await api.investorMetrics();
        setMetrics(m);
      } catch (e: any) {
        showError(e.message || 'Failed to load metrics');
      }
    })();
  }, []);

  return (
    <div className="card">
      <h2>Investor Dashboard</h2>
      {!metrics && <p>Loading metrics...</p>}
      {metrics && (
        <ul>
          <li>Total judgments: {metrics.totalJudgments}</li>
          <li>Total face value: ${metrics.totalFaceValue}</li>
          <li>Total recommended purchase price: ${metrics.totalRecommendedPrice}</li>
        </ul>
      )}
    </div>
  );
};
