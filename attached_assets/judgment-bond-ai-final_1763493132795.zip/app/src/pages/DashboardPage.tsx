import React from 'react';
import { AIOnboarderChat } from '../components/AIOnboarderChat';

export const DashboardPage: React.FC = () => {
  return (
    <div className="flex-row">
      <div className="flex-1">
        <div className="card">
          <h2>Dashboard</h2>
          <p>
            Welcome to Judgment Bond AI. Use the navigation to upload judgments, run AI extraction,
            and view investor analytics.
          </p>
        </div>
      </div>
      <AIOnboarderChat />
    </div>
  );
};
