import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './lib/auth';
import { Layout } from './components/Layout';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { DashboardPage } from './pages/DashboardPage';
import { JudgmentsPage } from './pages/JudgmentsPage';
import { BundlesPage } from './pages/BundlesPage';
import { InvestorDashboardPage } from './pages/InvestorDashboardPage';

export function App() {
  const { user } = useAuth();

  return (
    <Layout>
      <Routes>
        <Route
          path="/"
          element={user ? <Navigate to="/dashboard" /> : <Navigate to="/login" />}
        />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route
          path="/dashboard"
          element={user ? <DashboardPage /> : <Navigate to="/login" />}
        />
        <Route
          path="/judgments"
          element={user ? <JudgmentsPage /> : <Navigate to="/login" />}
        />
        <Route
          path="/bundles"
          element={user ? <BundlesPage /> : <Navigate to="/login" />}
        />
        <Route
          path="/investor-dashboard"
          element={user ? <InvestorDashboardPage /> : <Navigate to="/login" />}
        />
      </Routes>
    </Layout>
  );
}
