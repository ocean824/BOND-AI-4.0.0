import Fastify, { FastifyInstance } from 'fastify';
import cors from '@fastify/cors';
import fastifyStatic from '@fastify/static';
import fastifyJwt from 'fastify-jwt';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { config, AppConfig } from './config/env.js';
import { logger } from './config/logger.js';
import { registerRoutes } from './routes/index.js';
import { requestContextHook } from './middleware/requestContext.js';
import { AppError } from './errors/index.js';

declare module 'fastify' {
  interface FastifyInstance {
    config: AppConfig;
  }
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const app: FastifyInstance = Fastify({
  logger
});

app.decorate('config', config);

app.register(cors, {
  origin: config.FRONTEND_URL,
  credentials: true
});

app.register(fastifyJwt as any, {
  secret: config.JWT_SECRET,
  sign: {
    expiresIn: config.JWT_EXPIRES_IN
  }
});

app.register(fastifyStatic, {
  root: path.join(__dirname, '..', 'app', 'dist'),
  prefix: '/app/',
  decorateReply: false
});

app.addHook('onRequest', requestContextHook);

const cspValue = [
  "default-src 'self';",
  "script-src 'self' 'unsafe-inline' https://cdn.redoc.ly;",
  "style-src 'self' 'unsafe-inline';",
  "img-src 'self' data:;",
  "connect-src 'self' https://api.openai.com https://api.anthropic.com;",
  "frame-ancestors 'none';"
].join(' ');

app.addHook('onSend', (req, reply, payload, done) => {
  reply.header('X-Frame-Options', 'DENY');
  reply.header('X-Content-Type-Options', 'nosniff');
  reply.header('Referrer-Policy', 'strict-origin-when-cross-origin');

  if (!reply.getHeader('Content-Security-Policy')) {
    reply.header('Content-Security-Policy', cspValue);
  }

  done(null, payload);
});

app.setErrorHandler((err: any, req, reply) => {
  const requestId = (req as any).requestId ?? req.id;

  const isAppError = err instanceof AppError;
  const statusCode = isAppError ? err.statusCode : 500;
  const code = isAppError ? err.code : 'INTERNAL_ERROR';
  const details = isAppError ? err.details ?? null : null;

  const logLevel = statusCode >= 500 ? 'error' : 'warn';
  (req.log as any)[logLevel]({ err, requestId }, err.message);

  if (!reply.sent) {
    reply.status(statusCode).send({
      code,
      message: err.message ?? 'Unexpected error',
      details,
      requestId
    });
  }
});

async function start() {
  try {
    await registerRoutes(app);
    await app.listen({ port: config.PORT, host: '0.0.0.0' });
    app.log.info({ port: config.PORT }, 'Server listening');
  } catch (err) {
    app.log.error({ err }, 'Failed to start server');
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  start();
}
