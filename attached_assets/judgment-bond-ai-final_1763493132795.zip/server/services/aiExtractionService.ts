import { config } from '../config/env.js';
import OpenAI from 'openai';
import { ExternalServiceError } from '../errors/index.js';

const openai = new OpenAI({ apiKey: config.OPENAI_API_KEY });

export type ExtractionConfidenceSource = 'gpt' | 'claude' | 'both';

export interface JudgmentExtractionResult {
  debtorName: string;
  caseNumber: string;
  court: string;
  jurisdiction: string;
  judgmentAmount: number;
  judgmentDate: string;
  confidence: Record<string, ExtractionConfidenceSource>;
  rawFields: Record<string, unknown>;
}

async function callClaudeForExtraction(_text: string): Promise<Partial<JudgmentExtractionResult>> {
  if (!config.CLAUDE_API_KEY) {
    return {};
  }
  // Placeholder for real Claude API integration.
  return {};
}

async function callGPTForExtraction(text: string): Promise<Partial<JudgmentExtractionResult>> {
  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      response_format: { type: 'json_object' },
      messages: [
        {
          role: 'system',
          content:
            'You extract structured data from court judgments. Respond as compact JSON with keys: ' +
            'debtorName, caseNumber, court, jurisdiction, judgmentAmount, judgmentDate (ISO yyyy-mm-dd).'
        },
        { role: 'user', content: text }
      ]
    });

    const raw = completion.choices[0]?.message?.content ?? '{}';
    const parsed = JSON.parse(raw);

    const result: Partial<JudgmentExtractionResult> = {
      debtorName: parsed.debtorName,
      caseNumber: parsed.caseNumber,
      court: parsed.court,
      jurisdiction: parsed.jurisdiction,
      judgmentAmount: Number(parsed.judgmentAmount),
      judgmentDate: parsed.judgmentDate,
      rawFields: parsed
    };
    return result;
  } catch (err) {
    throw new ExternalServiceError('Failed to call OpenAI for extraction', err);
  }
}

export async function extractJudgmentData(text: string): Promise<JudgmentExtractionResult> {
  const [gpt, claude] = await Promise.allSettled([
    callGPTForExtraction(text),
    callClaudeForExtraction(text)
  ]);

  const merged: any = {};
  const confidence: Record<string, ExtractionConfidenceSource> = {};

  const pickField = (field: string) => {
    const g = gpt.status === 'fulfilled' ? (gpt.value as any)[field] : undefined;
    const c = claude.status === 'fulfilled' ? (claude.value as any)[field] : undefined;

    if (g !== undefined && c !== undefined) {
      if (g === c) {
        merged[field] = g;
        confidence[field] = 'both';
      } else {
        if (['debtorName', 'court', 'jurisdiction', 'caseNumber'].includes(field)) {
          merged[field] = c ?? g;
          confidence[field] = c !== undefined ? 'claude' : 'gpt';
        } else {
          merged[field] = g ?? c;
          confidence[field] = g !== undefined ? 'gpt' : 'claude';
        }
      }
    } else if (g !== undefined) {
      merged[field] = g;
      confidence[field] = 'gpt';
    } else if (c !== undefined) {
      merged[field] = c;
      confidence[field] = 'claude';
    }
  };

  pickField('debtorName');
  pickField('caseNumber');
  pickField('court');
  pickField('jurisdiction');
  pickField('judgmentAmount');
  pickField('judgmentDate');

  if (!merged.debtorName || !merged.caseNumber) {
    merged.debtorName = merged.debtorName ?? 'Unknown Debtor';
    merged.caseNumber = merged.caseNumber ?? 'UNKNOWN';
  }

  const rawFields =
    gpt.status === 'fulfilled'
      ? (gpt.value as any).rawFields ?? {}
      : claude.status === 'fulfilled'
      ? (claude.value as any).rawFields ?? {}
      : {};

  return {
    debtorName: merged.debtorName,
    caseNumber: merged.caseNumber,
    court: merged.court ?? 'Unknown Court',
    jurisdiction: merged.jurisdiction ?? 'Unknown Jurisdiction',
    judgmentAmount: Number(merged.judgmentAmount ?? 0),
    judgmentDate: merged.judgmentDate ?? new Date().toISOString().slice(0, 10),
    confidence,
    rawFields
  };
}
