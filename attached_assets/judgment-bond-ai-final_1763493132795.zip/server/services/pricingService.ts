import { priceEstimates, judgments } from '../../db/schema.js';
import { db } from '../db/client.js';
import { eq } from 'drizzle-orm';
import { NotFoundError } from '../errors/index.js';

export interface PricingInput {
  judgmentId: number;
  targetIRR: number;
  discountRate: number;
  expectedRecoveryPct: number;
}

export async function calculateAndPersistPrice(input: PricingInput) {
  const [judgment] = await db.select().from(judgments).where(eq(judgments.id, input.judgmentId));

  if (!judgment) {
    throw new NotFoundError('Judgment not found');
  }

  const expectedRecoveryAmount =
    Number(judgment.judgmentAmount) * (input.expectedRecoveryPct / 100);
  const purchasePrice =
    expectedRecoveryAmount * (1 - input.discountRate / 100);

  const [inserted] = await db
    .insert(priceEstimates)
    .values({
      judgmentId: input.judgmentId,
      targetIRR: input.targetIRR,
      discountRate: input.discountRate,
      recommendedPurchasePrice: purchasePrice,
      scenarioJson: {
        expectedRecoveryAmount,
        model: 'simple-linear',
        note:
          'Deterministic pricing. For production, replace with Monte Carlo or AI-augmented model.'
      }
    })
    .returning();

  return inserted;
}
