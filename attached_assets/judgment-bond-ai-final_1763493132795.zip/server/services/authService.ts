import { db } from '../db/client.js';
import { users } from '../../db/schema.js';
import { eq } from 'drizzle-orm';
import bcrypt from 'bcryptjs';
import { AuthError, ConflictError } from '../errors/index.js';

export async function registerUser(email: string, password: string, role: string = 'analyst') {
  const [existing] = await db.select().from(users).where(eq(users.email, email));
  if (existing) {
    throw new ConflictError('Email already in use');
  }
  const passwordHash = await bcrypt.hash(password, 10);
  const [created] = await db
    .insert(users)
    .values({ email, passwordHash, role })
    .returning();
  return created;
}

export async function verifyUser(email: string, password: string) {
  const [user] = await db.select().from(users).where(eq(users.email, email));
  if (!user) {
    throw new AuthError('Invalid credentials');
  }
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) {
    throw new AuthError('Invalid credentials');
  }
  return user;
}
