export async function buildAssistantReply(message: string): Promise<string> {
  const lower = message.toLowerCase();

  if (lower.includes('price') || lower.includes('purchase')) {
    return (
      'Pricing usually starts from expected recovery: estimate the % you expect to collect, ' +
      'multiply by the face value, then discount that amount by your target yield (IRR) and risk.'
    );
  }

  if (lower.includes('recovery')) {
    return (
      'Recovery % depends on factors like debtor assets, employment, liens, exemptions, and ' +
      'jurisdiction. Higher quality information and enforcement options generally raise recovery.'
    );
  }

  return (
    'This assistant explains high-level underwriting logic only. Combine judgment amount, ' +
    'expected recovery %, and discount rate to estimate a fair purchase price. This is not ' +
    'legal or investment advice.'
  );
}
