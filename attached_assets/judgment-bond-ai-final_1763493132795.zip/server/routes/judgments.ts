import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { authGuard } from '../middleware/auth.js';
import { db, dbRead } from '../db/client.js';
import { judgments } from '../../db/schema.js';
import { ValidationError, NotFoundError } from '../errors/index.js';
import { extractJudgmentData } from '../services/aiExtractionService.js';
import { and, eq } from 'drizzle-orm';
import { rateLimit } from '../middleware/rateLimit.js';

const uploadSchema = z.object({
  pdfBase64: z.string().min(10),
  notes: z.string().optional()
});

const extractSchema = z.object({
  rawText: z.string().min(10)
});

export async function judgmentRoutes(app: FastifyInstance) {
  app.addHook('onRequest', authGuard);

  app.get('/api/judgments', async (req, reply) => {
    const user = (req as any).user!;
    const { limit = '50', offset = '0', status } = (req.query as any) ?? {};

    const limitNum = Math.min(Math.max(Number(limit) || 50, 1), 200);
    const offsetNum = Math.max(Number(offset) || 0, 0);

    const where = status
      ? and(eq(judgments.ownerId, user.id), eq(judgments.status, status))
      : eq(judgments.ownerId, user.id);

    const rows = await dbRead
      .select()
      .from(judgments)
      .where(where)
      .limit(limitNum)
      .offset(offsetNum);

    reply.send(rows);
  });

  app.get('/api/judgments/:id', async (req) => {
    const user = (req as any).user!;
    const id = Number((req.params as any).id);
    const [row] = await db
      .select()
      .from(judgments)
      .where(eq(judgments.id, id));
    if (!row || row.ownerId !== user.id) {
      throw new NotFoundError('Judgment not found');
    }
    return row;
  });

  app.post('/api/judgments/upload', async (req) => {
    const user = (req as any).user!;
    const parse = uploadSchema.safeParse(req.body);
    if (!parse.success) {
      throw new ValidationError('Invalid upload payload', parse.error.format());
    }
    const [inserted] = await db
      .insert(judgments)
      .values({
        ownerId: user.id,
        debtorName: 'TBD',
        caseNumber: 'TBD',
        court: 'TBD',
        jurisdiction: 'TBD',
        judgmentAmount: 0,
        judgmentDate: new Date(),
        rawText: `PDF_BASE64_LENGTH=${parse.data.pdfBase64.length}`
      })
      .returning();
    return inserted;
  });

  app.post('/api/judgments/:id/extract', async (req, reply) => {
    const user = (req as any).user!;
    const id = Number((req.params as any).id);
    const parse = extractSchema.safeParse(req.body);
    if (!parse.success) {
      throw new ValidationError('Invalid extract payload', parse.error.format());
    }
    await rateLimit(req, reply, 'aiExtraction');
    const [row] = await db.select().from(judgments).where(eq(judgments.id, id));
    if (!row || row.ownerId !== user.id) {
      throw new NotFoundError('Judgment not found');
    }

    const result = await extractJudgmentData(parse.data.rawText);
    const [updated] = await db
      .update(judgments)
      .set({
        debtorName: result.debtorName,
        caseNumber: result.caseNumber,
        court: result.court,
        jurisdiction: result.jurisdiction,
        judgmentAmount: result.judgmentAmount,
        extractionJson: result.rawFields,
        extractionConfidence: result.confidence,
        rawText: parse.data.rawText,
        updatedAt: new Date()
      })
      .where(eq(judgments.id, id))
      .returning();

    return updated;
  });
}
