import { FastifyInstance } from 'fastify';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import YAML from 'yaml';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const OPENAPI_PATH = path.join(__dirname, '..', 'openapi.yml');

export async function docsRoutes(app: FastifyInstance) {
  app.get('/api/openapi.yml', async (_req, reply) => {
    const yamlText = await readFile(OPENAPI_PATH, 'utf-8');
    reply.type('application/yaml').send(yamlText);
  });

  app.get('/api/json', async (_req, reply) => {
    const yamlText = await readFile(OPENAPI_PATH, 'utf-8');
    const json = YAML.parse(yamlText);
    reply.type('application/json').send(json);
  });

  app.get('/api/docs', async (_req, reply) => {
    const html = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Judgment Bond AI – API Docs</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
  </head>
  <body>
    <redoc spec-url="/api/json"></redoc>
    <script src="https://cdn.redoc.ly/redoc/latest/bundles/redoc.standalone.js"></script>
  </body>
</html>`;
    reply.type('text/html; charset=utf-8').send(html);
  });
}
