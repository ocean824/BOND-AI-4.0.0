import { FastifyInstance } from 'fastify';
import { authRoutes } from './auth.js';
import { judgmentRoutes } from './judgments.js';
import { metricsRoutes } from './metrics.js';
import { healthRoutes } from './health.js';
import { assistantRoutes } from './assistant.js';
import { docsRoutes } from './docs.js';
import { teaserRoutes } from './teaser.js';

export async function registerRoutes(app: FastifyInstance) {
  await authRoutes(app);
  await judgmentRoutes(app);
  await assistantRoutes(app);
  await healthRoutes(app);
  await metricsRoutes(app);
  await docsRoutes(app);
  await teaserRoutes(app);
}
