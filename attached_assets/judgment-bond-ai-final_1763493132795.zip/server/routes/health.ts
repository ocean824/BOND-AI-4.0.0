import { FastifyInstance } from 'fastify';
import { db } from '../db/client.js';
import { sql } from 'drizzle-orm';
import { config } from '../config/env.js';

export async function healthRoutes(app: FastifyInstance) {
  app.get('/api/healthz', async (_req, reply) => {
    reply.send({
      status: 'ok',
      uptimeSeconds: process.uptime(),
      timestamp: new Date().toISOString()
    });
  });

  app.get('/api/readyz', async (_req, reply) => {
    const checks: Record<string, unknown> = {};
    let ready = true;

    try {
      await db.execute(sql`SELECT 1`);
      checks.database = { status: 'ok' };
    } catch (err) {
      ready = false;
      checks.database = { status: 'error', error: String(err) };
    }

    if (!config.OPENAI_API_KEY) {
      ready = false;
      checks.openai = { status: 'error', error: 'OPENAI_API_KEY missing' };
    } else {
      checks.openai = { status: 'ok' };
    }

    const statusCode = ready ? 200 : 503;
    reply.code(statusCode).send({
      status: ready ? 'ready' : 'degraded',
      checks,
      timestamp: new Date().toISOString()
    });
  });
}
