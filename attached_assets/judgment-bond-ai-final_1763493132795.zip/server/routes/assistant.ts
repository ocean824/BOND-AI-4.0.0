import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { authGuard } from '../middleware/auth.js';
import { ValidationError } from '../errors/index.js';
import { buildAssistantReply } from '../services/assistantService.js';
import { rateLimit } from '../middleware/rateLimit.js';

const chatSchema = z.object({
  message: z.string().min(1),
  contextJudgmentId: z.number().optional()
});

export async function assistantRoutes(app: FastifyInstance) {
  app.addHook('onRequest', authGuard);

  app.post('/api/assistant/chat', async (req, reply) => {
    const parse = chatSchema.safeParse(req.body);
    if (!parse.success) {
      throw new ValidationError('Invalid chat payload', parse.error.format());
    }
    await rateLimit(req, reply, 'chat');
    const replyText = await buildAssistantReply(parse.data.message);
    return { reply: replyText };
  });
}
