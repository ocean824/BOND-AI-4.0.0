import { FastifyInstance } from 'fastify';
import { authGuard } from '../middleware/auth.js';
import { dbRead } from '../db/client.js';
import { bundles } from '../../db/schema.js';
import { NotFoundError } from '../errors/index.js';
import PDFDocument from 'pdfkit';
import { sql } from 'drizzle-orm';

export async function teaserRoutes(app: FastifyInstance) {
  app.addHook('onRequest', authGuard);

  app.get('/api/bundles/:id/teaser', async (req, reply) => {
    const id = Number((req.params as any).id);
    if (!Number.isFinite(id) || id <= 0) {
      throw new NotFoundError('Bundle not found');
    }

    // Load bundle
    const [bundle] = await dbRead
      .select()
      .from(bundles)
      .where(bundles.id.eq(id as any) as any);

    if (!bundle) {
      throw new NotFoundError('Bundle not found');
    }

    // Load judgments & pricing summary for this bundle
    const rows = await dbRead.execute(
      sql`
        SELECT
          j.debtor_name,
          j.case_number,
          j.judgment_amount,
          pe.recommended_purchase_price
        FROM bundle_judgments bj
        JOIN judgments j ON j.id = bj.judgment_id
        LEFT JOIN price_estimates pe ON pe.judgment_id = j.id
        WHERE bj.bundle_id = ${id}
      `
    );

    const items = (rows as any[]).map((r) => ({
      debtorName: r.debtor_name,
      caseNumber: r.case_number,
      judgmentAmount: Number(r.judgment_amount ?? 0),
      recommendedPurchasePrice: Number(r.recommended_purchase_price ?? 0)
    }));

    const totalFaceValue = items.reduce(
      (sum, it) => sum + it.judgmentAmount,
      0
    );
    const totalRecommended = items.reduce(
      (sum, it) => sum + it.recommendedPurchasePrice,
      0
    );

    // Build PDF teaser
    const doc = new PDFDocument({ size: 'A4', margin: 50 });

    reply.header('Content-Type', 'application/pdf');
    reply.header(
      'Content-Disposition',
      `inline; filename="bundle-${id}-teaser.pdf"`
    );

    // Pipe PDF stream to Fastify raw response
    doc.pipe(reply.raw);

    doc.fontSize(20).text('Judgment Bond AI – Investor Teaser', {
      align: 'left'
    });
    doc.moveDown();
    doc.fontSize(14).text(`Bundle: ${bundle.name}`, { continued: true });
    doc.fontSize(12).text(`  (Status: ${bundle.status})`);
    if (bundle.description) {
      doc.moveDown(0.5);
      doc.fontSize(11).text(bundle.description);
    }

    doc.moveDown();
    doc.fontSize(12).text(
      `Total face value: $${totalFaceValue.toFixed(2)}`
    );
    doc.fontSize(12).text(
      `Total recommended purchase price: $${totalRecommended.toFixed(2)}`
    );
    doc.fontSize(12).text(
      `Judgment count: ${items.length}`
    );

    doc.moveDown();
    doc.fontSize(13).text('Judgments in Bundle:', { underline: true });
    doc.moveDown(0.5);

    if (items.length === 0) {
      doc.fontSize(11).text('No judgments assigned yet.');
    } else {
      items.forEach((it, idx) => {
        doc.fontSize(11).text(
          `${idx + 1}. Debtor: ${it.debtorName} | Case: ${
            it.caseNumber
          } | Face: $${it.judgmentAmount.toFixed(
            2
          )} | Recommended: $${it.recommendedPurchasePrice.toFixed(2)}`
        );
      });
    }

    doc.moveDown();
    doc.fontSize(10).text(
      'This teaser is for illustrative purposes only and is not legal or investment advice.',
      { align: 'left' }
    );

    doc.end();

    return reply;
  });
}
