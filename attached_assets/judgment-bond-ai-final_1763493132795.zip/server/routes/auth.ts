import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { registerUser, verifyUser } from '../services/authService.js';
import { ValidationError } from '../errors/index.js';
import { config } from '../config/env.js';

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8)
});

const registerSchema = loginSchema.extend({
  role: z.enum(['admin', 'analyst', 'investor']).optional()
});

export async function authRoutes(app: FastifyInstance) {
  app.post('/api/auth/register', async (req, reply) => {
    const parse = registerSchema.safeParse(req.body);
    if (!parse.success) {
      throw new ValidationError('Invalid register payload', parse.error.format());
    }
    const { email, password, role } = parse.data;
    const user = await registerUser(email, password, role);
    const token = (app as any).jwt.sign(
      {
        sub: user.id,
        email: user.email,
        role: user.role
      },
      { expiresIn: config.JWT_EXPIRES_IN }
    );
    reply.send({
      token,
      user: { id: user.id, email: user.email, role: user.role }
    });
  });

  app.post('/api/auth/login', async (req, reply) => {
    const parse = loginSchema.safeParse(req.body);
    if (!parse.success) {
      throw new ValidationError('Invalid login payload', parse.error.format());
    }
    const { email, password } = parse.data;
    const user = await verifyUser(email, password);
    const token = (app as any).jwt.sign(
      {
        sub: user.id,
        email: user.email,
        role: user.role
      },
      { expiresIn: config.JWT_EXPIRES_IN }
    );
    reply.send({
      token,
      user: { id: user.id, email: user.email, role: user.role }
    });
  });

  app.get('/api/auth/me', async (req, reply) => {
    const user = (req as any).user;
    if (!user) {
      return reply.code(401).send({ code: 'AUTH_ERROR', message: 'Not authenticated' });
    }
    reply.send({ user });
  });
}
