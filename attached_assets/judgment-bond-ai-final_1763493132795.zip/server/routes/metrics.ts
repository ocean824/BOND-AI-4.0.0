import { FastifyInstance } from 'fastify';
import { dbRead } from '../db/client.js';
import { sql } from 'drizzle-orm';

export async function metricsRoutes(app: FastifyInstance) {
  app.get('/api/investor-metrics', async (req, reply) => {
    const bundleIdParam = (req.query as any)?.bundleId;
    const _bundleId = bundleIdParam ? Number(bundleIdParam) : undefined;

    const [agg] = await dbRead.execute(
      sql`
        SELECT
          COUNT(j.id) AS "totalJudgments",
          COALESCE(SUM(j.judgment_amount), 0) AS "totalFaceValue",
          COALESCE(SUM(pe.recommended_purchase_price), 0) AS "totalRecommendedPrice"
        FROM judgments j
        LEFT JOIN price_estimates pe ON pe.judgment_id = j.id
      `
    );

    const metrics = {
      totalJudgments: Number((agg as any).totalJudgments ?? 0),
      totalFaceValue: Number((agg as any).totalFaceValue ?? 0),
      totalRecommendedPrice: Number((agg as any).totalRecommendedPrice ?? 0),
      seniorShare: 0,
      mezzShare: 0,
      equityShare: 0
    };

    reply.header('Cache-Control', 'public, max-age=30');
    reply.send(metrics);
  });

  app.get('/metrics', async (_req, reply) => {
    const mem = process.memoryUsage();
    const uptime = process.uptime();

    const lines = [
      '# HELP app_uptime_seconds Application uptime in seconds',
      '# TYPE app_uptime_seconds gauge',
      `app_uptime_seconds ${uptime}`,
      '# HELP app_heap_used_bytes Heap used in bytes',
      '# TYPE app_heap_used_bytes gauge',
      `app_heap_used_bytes ${mem.heapUsed}`,
      '# HELP app_rss_bytes Resident set size in bytes',
      '# TYPE app_rss_bytes gauge',
      `app_rss_bytes ${mem.rss}`
    ];

    reply
      .type('text/plain; version=0.0.4')
      .header('Cache-Control', 'no-store')
      .send(lines.join('\n') + '\n');
  });
}
