import { drizzle } from 'drizzle-orm/node-postgres';
import pg from 'pg';
import { config } from '../config/env.js';
import * as schema from '../../db/schema.js';

const { Pool } = pg;

/**
 * Primary write pool.
 */
export const pool = new Pool({
  connectionString: config.DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30000
});

export const db = drizzle(pool, { schema });
export const dbRead = db;
