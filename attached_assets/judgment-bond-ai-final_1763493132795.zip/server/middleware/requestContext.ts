import { FastifyReply, FastifyRequest } from 'fastify';
import { randomUUID } from 'node:crypto';

declare module 'fastify' {
  interface FastifyRequest {
    requestId?: string;
  }
}

export async function requestContextHook(req: FastifyRequest, reply: FastifyReply) {
  const id = (req.id as string) || randomUUID();
  req.requestId = id;
  reply.header('X-Request-Id', id);
}
