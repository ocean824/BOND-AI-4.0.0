import { FastifyReply, FastifyRequest } from 'fastify';
import { rateLimits } from '../../config/rateLimits.js';
import { RateLimitError } from '../errors/index.js';

type RateKey = 'aiExtraction' | 'pricing' | 'chat';

interface Bucket {
  count: number;
  windowStart: number;
}

const windowMs = 60000;
const buckets = new Map<string, Bucket>();

function getLimit(key: RateKey): number {
  switch (key) {
    case 'aiExtraction':
      return rateLimits.aiExtractionPerMinute;
    case 'pricing':
      return rateLimits.pricingPerMinute;
    case 'chat':
      return rateLimits.chatPerMinute;
  }
}

function bucketIdFor(req: FastifyRequest, key: RateKey): string {
  const user = (req as any).user;
  const ip =
    (req.headers['x-forwarded-for'] as string) ||
    req.ip ||
    (req.raw.socket.remoteAddress ?? 'unknown');
  if (user?.id) {
    return `${key}:user:${user.id}`;
  }
  return `${key}:ip:${ip}`;
}

export async function rateLimit(
  req: FastifyRequest,
  _reply: FastifyReply,
  key: RateKey
): Promise<void> {
  const id = bucketIdFor(req, key);
  const now = Date.now();
  const limit = getLimit(key);

  const bucket = buckets.get(id);
  if (!bucket) {
    buckets.set(id, { count: 1, windowStart: now });
    return;
  }

  if (now - bucket.windowStart > windowMs) {
    bucket.count = 1;
    bucket.windowStart = now;
    return;
  }

  bucket.count += 1;

  if (bucket.count > limit) {
    throw new RateLimitError(
      `Rate limit exceeded for ${key} (${bucket.count}/${limit} in current window)`
    );
  }
}
