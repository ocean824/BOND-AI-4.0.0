import { FastifyReply, FastifyRequest } from 'fastify';
import { AuthError } from '../errors/index.js';

export interface AuthUser {
  id: number;
  email: string;
  role: string;
}

declare module 'fastify' {
  interface FastifyRequest {
    user?: AuthUser;
  }
}

export async function authGuard(request: FastifyRequest, _reply: FastifyReply) {
  try {
    const decoded = await (request as any).jwtVerify();
    const payload = decoded as any;
    if (!payload || (!payload.sub && !payload.id)) {
      throw new AuthError('Invalid token payload');
    }
    request.user = {
      id: Number(payload.sub ?? payload.id),
      email: String(payload.email),
      role: String(payload.role)
    };
  } catch (err) {
    throw new AuthError('Invalid or missing token', err);
  }
}
