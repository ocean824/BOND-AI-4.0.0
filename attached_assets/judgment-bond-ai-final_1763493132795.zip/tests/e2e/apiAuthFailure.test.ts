import { describe, it, expect } from 'vitest';
import request from 'supertest';

const BASE = 'http://localhost:3000';

describe('API Auth failure E2E', () => {
  it('rejects unauthenticated access to /api/judgments', async () => {
    const res = await request(BASE).get('/api/judgments');
    expect([401, 403]).toContain(res.status);
  });
});
