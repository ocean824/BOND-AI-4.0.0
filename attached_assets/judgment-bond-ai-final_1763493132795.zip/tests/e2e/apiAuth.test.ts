import { describe, it, expect } from 'vitest';
import request from 'supertest';

const BASE = 'http://localhost:3000';

describe('API Auth E2E', () => {
  it('registers and logs in a user', async () => {
    const email = `user_${Date.now()}@example.com`;
    const password = 'Password123!';

    const reg = await request(BASE)
      .post('/api/auth/register')
      .send({ email, password });

    expect(reg.status).toBe(200);
    expect(reg.body.token).toBeDefined();

    const login = await request(BASE)
      .post('/api/auth/login')
      .send({ email, password });

    expect(login.status).toBe(200);
    expect(login.body.token).toBeDefined();
  });
});
