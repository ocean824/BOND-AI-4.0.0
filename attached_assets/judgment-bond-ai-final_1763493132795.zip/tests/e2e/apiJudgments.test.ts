import { describe, it, expect } from 'vitest';
import request from 'supertest';

const BASE = 'http://localhost:3000';

async function loginAsAdmin() {
  const res = await request(BASE)
    .post('/api/auth/login')
    .send({ email: 'admin@example.com', password: 'Admin123!' });
  return res.body.token as string;
}

describe('API Judgments E2E', () => {
  it('lists judgments for authenticated user', async () => {
    const token = await loginAsAdmin();
    const res = await request(BASE)
      .get('/api/judgments')
      .set('Authorization', `Bearer ${token}`);

    expect([200, 401]).toContain(res.status);
  });
});
