import { describe, it, expect } from 'vitest';
import { rateLimit } from '../../server/middleware/rateLimit.js';
import { RateLimitError } from '../../server/errors/index.js';

describe('rateLimit middleware', () => {
  it('allows a small number of calls and then throws', async () => {
    const req: any = { headers: {}, ip: '127.0.0.1' };
    const reply: any = {};
    let threw = false;

    for (let i = 0; i < 20; i++) {
      try {
        await rateLimit(req, reply, 'aiExtraction');
      } catch (err) {
        expect(err).toBeInstanceOf(RateLimitError);
        threw = true;
        break;
      }
    }
    expect(threw).toBe(true);
  });
});
