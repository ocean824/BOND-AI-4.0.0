import { describe, it, expect } from 'vitest';
import {
  AppError,
  ValidationError,
  AuthError,
  RateLimitError,
  ExternalServiceError,
  ConflictError,
  NotFoundError
} from '../../server/errors/index.js';

describe('error classes', () => {
  it('wraps basic AppError shape', () => {
    const err = new AppError(418, 'I_AM_A_TEAPOT', 'short and stout');
    expect(err.statusCode).toBe(418);
    expect(err.code).toBe('I_AM_A_TEAPOT');
    expect(err.message).toContain('short');
  });

  it('provides typed subclasses with expected status codes', () => {
    expect(new ValidationError().statusCode).toBe(400);
    expect(new AuthError().statusCode).toBe(401);
    expect(new RateLimitError().statusCode).toBe(429);
    expect(new ExternalServiceError().statusCode).toBe(502);
    expect(new ConflictError().statusCode).toBe(409);
    expect(new NotFoundError().statusCode).toBe(404);
  });
});
