import { describe, it, expect } from 'vitest';

describe('envDoctor basic', () => {
  it('DATABASE_URL should be defined in test env', () => {
    expect(process.env.DATABASE_URL).toBeDefined();
  });
});
