import { describe, it, expect } from 'vitest';

describe('pricingService basic', () => {
  it('dummy formula expectations', () => {
    const judgmentAmount = 100000;
    const expectedRecoveryPct = 60;
    const discountRate = 30;
    const expectedRecoveryAmount = judgmentAmount * (expectedRecoveryPct / 100);
    const purchasePrice = expectedRecoveryAmount * (1 - discountRate / 100);
    expect(purchasePrice).toBe(42000);
  });
});
