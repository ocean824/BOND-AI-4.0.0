import { describe, it, expect } from 'vitest';
import { buildAssistantReply } from '../../server/services/assistantService.js';

describe('assistantService', () => {
  it('answers pricing questions with guidance', async () => {
    const msg = 'How should I price this judgment?';
    const reply = await buildAssistantReply(msg);
    expect(reply.toLowerCase()).toContain('pricing');
  });
});
