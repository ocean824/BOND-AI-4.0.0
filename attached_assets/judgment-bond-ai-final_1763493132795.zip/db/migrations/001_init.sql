CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(32) NOT NULL DEFAULT 'analyst',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE judgments (
  id SERIAL PRIMARY KEY,
  owner_id INTEGER NOT NULL REFERENCES users(id),
  debtor_name VARCHAR(255) NOT NULL,
  case_number VARCHAR(128) NOT NULL,
  court VARCHAR(255) NOT NULL,
  jurisdiction VARCHAR(255) NOT NULL,
  judgment_amount NUMERIC(18,2) NOT NULL,
  judgment_date TIMESTAMPTZ NOT NULL,
  status VARCHAR(64) NOT NULL DEFAULT 'new',
  pdf_storage_path TEXT,
  raw_text TEXT,
  extraction_json JSONB,
  extraction_confidence JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE recovery_scores (
  id SERIAL PRIMARY KEY,
  judgment_id INTEGER NOT NULL REFERENCES judgments(id),
  model VARCHAR(64) NOT NULL,
  score INTEGER NOT NULL,
  expected_recovery_pct NUMERIC(5,2) NOT NULL,
  rationale TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE price_estimates (
  id SERIAL PRIMARY KEY,
  judgment_id INTEGER NOT NULL REFERENCES judgments(id),
  target_irr NUMERIC(5,2) NOT NULL,
  discount_rate NUMERIC(5,2) NOT NULL,
  recommended_purchase_price NUMERIC(18,2) NOT NULL,
  scenario_json JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE bundles (
  id SERIAL PRIMARY KEY,
  owner_id INTEGER NOT NULL REFERENCES users(id),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  status VARCHAR(64) NOT NULL DEFAULT 'draft',
  metrics_json JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE bundle_judgments (
  id SERIAL PRIMARY KEY,
  bundle_id INTEGER NOT NULL REFERENCES bundles(id),
  judgment_id INTEGER NOT NULL REFERENCES judgments(id),
  tranche VARCHAR(32) NOT NULL DEFAULT 'senior'
);

CREATE TABLE chat_sessions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  context_judgment_id INTEGER REFERENCES judgments(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE chat_messages (
  id SERIAL PRIMARY KEY,
  session_id INTEGER NOT NULL REFERENCES chat_sessions(id),
  role VARCHAR(16) NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_judgments_owner ON judgments(owner_id);
CREATE INDEX idx_recovery_scores_judgment ON recovery_scores(judgment_id);
CREATE INDEX idx_price_estimates_judgment ON price_estimates(judgment_id);
CREATE INDEX idx_bundle_judgments_bundle ON bundle_judgments(bundle_id);
CREATE INDEX idx_bundle_judgments_judgment ON bundle_judgments(judgment_id);
