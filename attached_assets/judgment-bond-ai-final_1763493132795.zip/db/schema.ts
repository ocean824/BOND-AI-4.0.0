import {
  pgTable,
  serial,
  varchar,
  text,
  numeric,
  timestamp,
  integer,
  jsonb
} from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  passwordHash: varchar('password_hash', { length: 255 }).notNull(),
  role: varchar('role', { length: 32 }).notNull().default('analyst'),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow()
});

export const judgments = pgTable('judgments', {
  id: serial('id').primaryKey(),
  ownerId: integer('owner_id').notNull().references(() => users.id),
  debtorName: varchar('debtor_name', { length: 255 }).notNull(),
  caseNumber: varchar('case_number', { length: 128 }).notNull(),
  court: varchar('court', { length: 255 }).notNull(),
  jurisdiction: varchar('jurisdiction', { length: 255 }).notNull(),
  judgmentAmount: numeric('judgment_amount', { precision: 18, scale: 2 }).notNull(),
  judgmentDate: timestamp('judgment_date', { withTimezone: true }).notNull(),
  status: varchar('status', { length: 64 }).notNull().default('new'),
  pdfStoragePath: text('pdf_storage_path'),
  rawText: text('raw_text'),
  extractionJson: jsonb('extraction_json'),
  extractionConfidence: jsonb('extraction_confidence'),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow()
});

export const recoveryScores = pgTable('recovery_scores', {
  id: serial('id').primaryKey(),
  judgmentId: integer('judgment_id').notNull().references(() => judgments.id),
  model: varchar('model', { length: 64 }).notNull(),
  score: integer('score').notNull(),
  expectedRecoveryPct: numeric('expected_recovery_pct', { precision: 5, scale: 2 }).notNull(),
  rationale: text('rationale'),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow()
});

export const priceEstimates = pgTable('price_estimates', {
  id: serial('id').primaryKey(),
  judgmentId: integer('judgment_id').notNull().references(() => judgments.id),
  targetIRR: numeric('target_irr', { precision: 5, scale: 2 }).notNull(),
  discountRate: numeric('discount_rate', { precision: 5, scale: 2 }).notNull(),
  recommendedPurchasePrice: numeric('recommended_purchase_price', { precision: 18, scale: 2 }).notNull(),
  scenarioJson: jsonb('scenario_json'),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow()
});

export const bundles = pgTable('bundles', {
  id: serial('id').primaryKey(),
  ownerId: integer('owner_id').notNull().references(() => users.id),
  name: varchar('name', { length: 255 }).notNull(),
  description: text('description'),
  status: varchar('status', { length: 64 }).notNull().default('draft'),
  metricsJson: jsonb('metrics_json'),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow()
});

export const bundleJudgments = pgTable('bundle_judgments', {
  id: serial('id').primaryKey(),
  bundleId: integer('bundle_id').notNull().references(() => bundles.id),
  judgmentId: integer('judgment_id').notNull().references(() => judgments.id),
  tranche: varchar('tranche', { length: 32 }).notNull().default('senior')
});

export const chatSessions = pgTable('chat_sessions', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id),
  contextJudgmentId: integer('context_judgment_id').references(() => judgments.id),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow()
});

export const chatMessages = pgTable('chat_messages', {
  id: serial('id').primaryKey(),
  sessionId: integer('session_id').notNull().references(() => chatSessions.id),
  role: varchar('role', { length: 16 }).notNull(),
  content: text('content').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow()
});
