# Investor Bond Exchange React Pages

This folder contains drop-in React components you can mount in your existing
frontend:

- InvestorOverview.tsx — shows only aggregated totals of upcoming perfected bonds
- InvestorExchange.tsx — lists active auctions and allows an investor to place bids
- InvestorMyBids.tsx — shows the logged-in investor's own bids

All components assume that:

- Your API is hosted on the same origin as the frontend.
- The backend routes from this module are available:

  - GET /investor/overview
  - GET /investor/auctions
  - GET /investor/auctions/:id
  - POST /investor/auctions/:id/bids
  - GET /investor/my-bids

To integrate:

1. Import the component into your router / layout:

   ```tsx
   import { InvestorOverview } from "../frontend/investors/InvestorOverview";
   ```

2. Render it in a route that is only accessible for users with `role === "INVESTOR"`.

3. Wire your real auth into `src/index.ts` in place of the demo middleware so
   that `req.user` is populated with the correct user and role.

Investors must never see any other parts of the app; enforce this in both the
backend (with the `blockInvestorsForNonInvestorRoutes` middleware) and the
frontend (role-based navigation).
