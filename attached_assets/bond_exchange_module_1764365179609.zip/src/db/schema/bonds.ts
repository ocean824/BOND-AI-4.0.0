import {
  pgTable,
  uuid,
  numeric,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

export const bonds = pgTable("bonds", {
  id: uuid("id").primaryKey().defaultRandom(),
  faceValue: numeric("face_value", { precision: 18, scale: 2 }).notNull(),
  isPerfected: boolean("is_perfected").notNull().default(false),
  perfectedAt: timestamp("perfected_at", { withTimezone: true }),
  expectedPerfectedAt: timestamp("expected_perfected_at", {
    withTimezone: true,
  }),
  currentAuctionId: uuid("current_auction_id"),
});
