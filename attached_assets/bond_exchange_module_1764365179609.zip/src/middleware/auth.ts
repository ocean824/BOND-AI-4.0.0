import { Request, Response, NextFunction } from "express";

export type AppRole = "ADMIN" | "UNDERWRITER" | "INTERNAL" | "INVESTOR";

export interface AuthUser {
  id: string;
  role: AppRole;
  email: string;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

export function requireAuth(allowedRoles?: AppRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    if (allowedRoles && !allowedRoles.includes(user.role)) {
      return res.status(403).json({ error: "Forbidden" });
    }
    next();
  };
}

// If a user is an INVESTOR, they are only allowed to access /investor/* and /auth/*
export function blockInvestorsForNonInvestorRoutes(
  req: Request,
  res: Response,
  next: NextFunction
) {
  const user = req.user;
  if (user?.role === "INVESTOR") {
    const path = req.path;
    if (path.startsWith("/investor/") || path.startsWith("/auth/")) {
      return next();
    }
    return res
      .status(403)
      .json({ error: "Investors cannot access this resource" });
  }
  next();
}
