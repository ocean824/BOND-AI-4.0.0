import express from "express";
import dotenv from "dotenv";
import { json } from "express";
import { investorOverviewRouter } from "./routes/investorOverview";
import { investorAuctionsRouter } from "./routes/investorAuctions";
import { investorBidsRouter } from "./routes/investorBids";
import { blockInvestorsForNonInvestorRoutes } from "./middleware/auth";

dotenv.config();

const app = express();
app.use(json());

// TODO: Replace this with your real auth integration.
// For now, every request is treated as a demo INVESTOR user so you can test the module.
app.use((req, _res, next) => {
  (req as any).user = {
    id: "demo-investor-id",
    email: "investor@example.com",
    role: "INVESTOR",
  };
  next();
});

// Global guard: investors cannot hit non-investor routes
app.use(blockInvestorsForNonInvestorRoutes);

// Investor-facing routes
app.use(investorOverviewRouter);
app.use(investorAuctionsRouter);
app.use(investorBidsRouter);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Bond Exchange investor module listening on port ${PORT}`);
});
